package cn.bmob.imdemo.event;

/**
 * Created by Administrator on 2016/4/28.
 */
public class RefreshEvent {
    public RefreshEvent(){}
}
